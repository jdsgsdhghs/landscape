## Polices et dimensions

Polices utilisées :
- En général : Open Sans
- Pour les titres : PT Sans Narrow

Taille maximale du <main> : 1400px de large

## Breakpoints pour les medias queries

Taille minimale tablette : 570px
Taille minimale desktop : 1000px

## Remarques

Vous utiliserez l'approche mobile-first, qui consiste à démarrer l'intégration et le CSS à partir de la maquette mobile, et adapterez les éléments pour les autres breakpoints :

**mobile > tablette > desktop**